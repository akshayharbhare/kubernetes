UPDATE mmar_mep_messages_and_errors
    SET message = N'與您的客戶經理聯繫'
  WHERE message_code = 'LANDING_HEADER_MESSAGE'
    AND language_code = 'zh_tw';
	
 --simplified
 UPDATE mmar_mep_messages_and_errors
    SET message = N'与您的客户经理联系'
  WHERE message_code = 'LANDING_HEADER_MESSAGE'
    AND language_code = 'zh_cn';