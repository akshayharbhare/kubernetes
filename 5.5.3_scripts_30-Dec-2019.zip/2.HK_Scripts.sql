update EFM_EXPORT_FILE_MASTER set report_header_name = 'HK My RM' where file_type_id in ('USER-LIST','USER-ACCESS-MATRIX');


	--HK
INSERT INTO mmar_mep_messages_and_errors
  (message_id, message_code, message_description, message, language_code,
   created_date, updated_date, last_updated_by, om_id)
VALUES
  (concat('MMAR-N-', next value for mmar_seq), 'RM_TERMSANDCONDITION_HYPERLINK_TEXT',
   'RM Terms and Condition Hyper Link Text',
   'Important: You must read the [u]disclaimer[/u] before proceeding',
   'en', NULL, NULL, NULL, 'OM-1');

-- Simplified Chinese
INSERT INTO mmar_mep_messages_and_errors
  (message_id, message_code, message_description, message, language_code,
   created_date, updated_date, last_updated_by, om_id)
VALUES
  (concat('MMAR-N-', next value for mmar_seq), 'RM_TERMSANDCONDITION_HYPERLINK_TEXT',
   'RM Terms and Condition Hyper Link Text',
   N'重要提示：在继续操作之前，您必须阅读[u]免责声明[/u]',
   'zh_cn', NULL, NULL, NULL, 'OM-1');
-- Traditional Chinese
INSERT INTO mmar_mep_messages_and_errors
  (message_id, message_code, message_description, message, language_code,
   created_date, updated_date, last_updated_by, om_id)
VALUES
  (concat('MMAR-N-', next value for mmar_seq), 'RM_TERMSANDCONDITION_HYPERLINK_TEXT',
   'RM Terms and Condition Hyper Link Text',
   N'重要提示：在繼續操作之前，您必須閱讀[u]免責聲明[/u]',
   'zh_tw', NULL, NULL, NULL, 'OM-1');