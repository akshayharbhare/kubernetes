update EFM_EXPORT_FILE_MASTER set report_header_name = 'UAE My RM' where file_type_id in ('USER-LIST','USER-ACCESS-MATRIX');


	--UAE
INSERT INTO mmar_mep_messages_and_errors
  (message_id, message_code, message_description, message, language_code,
   created_date, updated_date, last_updated_by, om_id)
VALUES
  (concat('MMAR-N-', next value for mmar_seq), 'RM_TERMSANDCONDITION_HYPERLINK_TEXT',
   'RM Terms and Condition Hyper Link Text',
   '[u]Term and Condition[/u]',
   'en', NULL, NULL, NULL, 'OM-1');

-- Simplified Chinese
INSERT INTO mmar_mep_messages_and_errors
  (message_id, message_code, message_description, message, language_code,
   created_date, updated_date, last_updated_by, om_id)
VALUES
  (concat('MMAR-N-', next value for mmar_seq), 'RM_TERMSANDCONDITION_HYPERLINK_TEXT',
   'RM Terms and Condition Hyper Link Text',
   N'[u]规则与条例[/u]',
   'zh_cn', NULL, NULL, NULL, 'OM-1');
-- Traditional Chinese
INSERT INTO mmar_mep_messages_and_errors
  (message_id, message_code, message_description, message, language_code,
   created_date, updated_date, last_updated_by, om_id)
VALUES
  (concat('MMAR-N-', next value for mmar_seq), 'RM_TERMSANDCONDITION_HYPERLINK_TEXT',
   'RM Terms and Condition Hyper Link Text',
   N'[u]規則與條例[/u]',
   'zh_tw', NULL, NULL, NULL, 'OM-1');